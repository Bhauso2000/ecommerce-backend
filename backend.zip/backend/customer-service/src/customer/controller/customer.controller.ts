import { Body, Controller, Get, Post, Request } from '@nestjs/common';
import { MessagePattern, Payload, RpcException } from '@nestjs/microservices';
import { CustomerSevice } from '../service/customer.service';
import { SignUpDto } from '../dto/create-customer.dto';
import { LoginCustomerDto } from '../dto/login-customer.dto';
import { ApiBearerAuth, ApiBody, ApiTags } from '@nestjs/swagger';

@ApiTags('AuthController')
@Controller('customer')
export class CustomerController {
  constructor(private readonly customerService: CustomerSevice) {}

  // HTTP POST /customer/signup
  @ApiBody({ type: SignUpDto })
  @Post('signup')
  async signup(@Body() dto: SignUpDto) {
    return this.customerService.create(dto);
  }

  // HTTP POST /customer/login
  @ApiBody({ type: LoginCustomerDto })
  @Post('login')
  async login(@Body() dto: LoginCustomerDto) {
    return this.customerService.login(dto.email, dto.password);
  }

  // HTTP GET /customer/authuser
  @ApiBearerAuth('access-token')
  @Get('authuser')
  async getProfile(@Request() req) {
    return this.customerService.getAuthUser(req.user.sub);
  }

  // Microservice message pattern handlers:

@MessagePattern('create_customer')
async handleCreateCustomer(@Payload() dto: SignUpDto) {
  try {
    return await this.customerService.create(dto);
  } catch (error) {
    console.error('Error creating customer:', error);
    throw new RpcException('Failed to create customer');
  }
}


@MessagePattern('login_customer')
async handleLoginCustomer(@Payload() payload: { email: string; password: string }) {
  try {
    console.log('Received login payload:', payload);
    const result = await this.customerService.login(payload.email, payload.password);
    return result;
  } catch (error) {
    console.error('Error in customerService.login:', error);
    throw new RpcException('Login failed');
  }
}


  @MessagePattern('get_auth_user')
  async handleGetAuthUser(@Payload() userId: string) {
    return this.customerService.getAuthUser(userId);
  }
}
