import { IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class LoginCustomerDto {
  @ApiProperty({
    example: 'john.doe@example.com',
    description: 'Email address of the customer',
  })
  @IsString()
  email: string;

  @ApiProperty({
    example: 'yourPassword123',
    description: 'Password of the customer',
  })
  @IsString()
  password: string;
}
