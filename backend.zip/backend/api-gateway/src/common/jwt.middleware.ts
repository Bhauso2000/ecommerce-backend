import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class JwtMiddleware implements NestMiddleware {
  constructor(private readonly jwtService: JwtService) {}

  use(req: Request, res: Response, next: NextFunction) {
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
      return res.status(401).json({
        statusCode: 401,
        error: 'Unauthorized',
        message: 'Authorization header is missing',
      });
    }

    const [bearer, token] = authHeader.split(' ');

    if (bearer !== 'Bearer' || !token) {
      return res.status(401).json({
        statusCode: 401,
        error: 'Unauthorized',
        message: 'Authorization header must be in the format: Bearer <token>',
      });
    }

    try {
      const decoded = this.jwtService.verify(token, {
        secret: process.env.JWT_SECRET,
      });
      req['user'] = decoded;
      next();
    } catch (err) {
      return res.status(401).json({
        statusCode: 401,
        error: 'Unauthorized',
        message: 'Token is invalid or has expired',
      });
    }
  }
}
