import { Injectable, UnauthorizedException } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { PrismaService } from "src/common/prisma.service";
import { SignUpDto } from "../dto/create-customer.dto";
import * as bcrypt from 'bcrypt'
@Injectable()
export class CustomerSevice {
    constructor(
        private prisma: PrismaService,
        private jwtService: JwtService
    ) { }
    async create(createCustomerDto: SignUpDto) {
        const hashedPassword = await bcrypt.hash(createCustomerDto.password, 10)
        const customer = await this.prisma.customer.create({
            data: {
                ...createCustomerDto,
                password: hashedPassword
            }
        });
        const payload = {
            sub: customer.id,
            email: customer.email,
            role: customer.role
        }
        const token = this.jwtService.sign(payload);
        return {
            token: token,
            customer: customer
        }
    }
    async login(email: string, password: string) {
        const customer = await this.validateCustomer(email, password)
        const payload = {
            sub: customer.id,
            email: customer.email,
            role: customer.role
        }
        return {
            token: this.jwtService.sign(payload)
        }
    }
    async validateCustomer(email: string, password: string) {
        const customer = await this.prisma.customer.findUnique({
            where: { email }
        });
        if (!customer) throw new UnauthorizedException('Invalid credentials')
        const isMatch = await bcrypt.compare(password, customer.password)
        if (!isMatch) throw new UnauthorizedException('Invalid credentials')
        return customer
    }
   async getAuthUser(id: string) {
  const customer = await this.prisma.customer.findUnique({
    where: { id },
  });

  if (!customer) {
    throw new UnauthorizedException('User not found');
  }

  const { password, ...rest } = customer;
  return rest;
}

    

}