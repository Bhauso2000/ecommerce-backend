import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { CreateProductDto } from '../dto/create-product.dto';
import { CloudinaryService } from 'src/cloudinary/cloudinary.service';
import { UpdateProductDto } from '../dto/update-product-dto';


@Injectable()
export class ProductService {
  constructor(
    private prisma: PrismaService,
    private cloudinary: CloudinaryService,
  ) { }
async create(file: Express.Multer.File | string | undefined, dto: CreateProductDto) {
  let imageUrl =  '';
  if (file) {
    if (typeof file === 'string') {
      // file is base64 string
      const uploadResult = await this.cloudinary.uploadBase64Image(file);
      imageUrl = uploadResult.secure_url;
      console.log('Imagedfgfgf',imageUrl)
    } else {
      // file is Multer file
      const uploadResult = await this.cloudinary.uploadImage(file);
      console.log('Imagedfgfgf',imageUrl)

      imageUrl = uploadResult.secure_url;
    }
  }

  if (!imageUrl) {
    imageUrl = 'https://example.com/default-image.jpg';
  }

  return this.prisma.product.create({
    data: {
      name: dto.name,
      description: dto.description,
      price: Number(dto.price),
      imageUrl,
      stock: Number(dto.stock),
    },
  });
}



  async findAll() {
    return this.prisma.product.findMany();
  }

  async findOne(id: string) {
    const product = await this.prisma.product.findUnique({ where: { id } });
    if (!product) throw new NotFoundException('Product not found');
    return product;
  }

  async update(
    id: string,
    file: Express.Multer.File | undefined,
    dto: UpdateProductDto,
  ) {
    const existingProduct = await this.prisma.product.findUnique({ where: { id } });

    if (!existingProduct) {
      throw new Error('Product not found');
    }

    let imageUrl = dto.imageUrl ?? existingProduct.imageUrl;

    if (file) {
      const oldImageUrl = existingProduct.imageUrl;
      const publicId = this.extractPublicIdFromUrl(oldImageUrl);

      if (publicId) {
        await this.cloudinary.destroyImage(publicId);
      }

      const uploadResult = await this.cloudinary.uploadImage(file);
      imageUrl = uploadResult.secure_url;
    }

    // Destructure dto to exclude any 'file' property if accidentally present
    const { file: _file, ...dtoWithoutFile } = dto as any;

    const dataToUpdate = {
      ...dtoWithoutFile,
      price: dto.price !== undefined ? parseFloat(dto.price as any) : undefined,
      imageUrl,
    };

    // Remove undefined fields so Prisma doesn't try to update with undefined
    Object.keys(dataToUpdate).forEach(
      (key) => dataToUpdate[key] === undefined && delete dataToUpdate[key],
    );

    return this.prisma.product.update({
      where: { id },
      data: dataToUpdate,
    });
  }


  // Helper to extract public ID from Cloudinary URL
  extractPublicIdFromUrl(url: string): string | null {
    try {


      const urlObj = new URL(url);
      const pathname = urlObj.pathname;
      const parts = pathname.split('/');
      const uploadIndex = parts.indexOf('upload');
      if (uploadIndex === -1) return null;


      const publicIdParts = parts.slice(uploadIndex + 2);

      let publicIdWithExt = publicIdParts.join('/');
      const lastDotIndex = publicIdWithExt.lastIndexOf('.');
      if (lastDotIndex !== -1) {
        publicIdWithExt = publicIdWithExt.substring(0, lastDotIndex);
      }
      return publicIdWithExt;
    } catch {
      return null;
    }
  }



  async remove(id: string) {
    await this.findOne(id);
    return this.prisma.product.delete({ where: { id } });
  }
  async decreaseStock(productId: string, quantity: number) {
    const product = await this.prisma.product.findUnique({ where: { id: productId } });
    if (!product) {
      throw new NotFoundException('Product not found');
    }

    if (product.stock < quantity) {
      throw new BadRequestException('Insufficient stock');
    }

    const updatedProduct = await this.prisma.product.update({
      where: { id: productId },
      data: { stock: product.stock - quantity },
    });

    return updatedProduct;
  }

  async increaseStock(productId: string, quantity: number) {
    const product = await this.prisma.product.findUnique({ where: { id: productId } });
    if (!product) {
      throw new NotFoundException('Product not found');
    }

    const updatedProduct = await this.prisma.product.update({
      where: { id: productId },
      data: { stock: product.stock + quantity },
    });

    return updatedProduct;
  }
async searchProducts(
  page: number,
  limit: number,
  search: string = '',
  order: 'asc' | 'desc' = 'asc' // make order strict if you want
) {
  const skip = (page - 1) * limit;

  const [products, total] = await Promise.all([
    this.prisma.product.findMany({
      where: search
        ? {
            OR: [
              { name: { contains: search, mode: 'insensitive' } },
              { description: { contains: search, mode: 'insensitive' } },
            ],
          }
        : {},
      skip,
      take: limit,
      orderBy: { price: order }, // <-- Use price field and order param here
    }),
    this.prisma.product.count({
      where: search
        ? {
            OR: [
              { name: { contains: search, mode: 'insensitive' } },
              { description: { contains: search, mode: 'insensitive' } },
            ],
          }
        : {},
    }),
  ]);

  return {
    data: products,
    total,
    page,
    limit,
    totalPages: Math.ceil(total / limit),
  };
}


}