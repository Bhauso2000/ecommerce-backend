import { Module } from '@nestjs/common';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { CartOrderController } from './controller/cart-order.controller';
import { CartOrderService } from './services/cart-order.service';
import { PrismaService } from './prisma/prisma.service';

@Module({
  imports: [
    ClientsModule.register([
      {
        name: 'PRODUCT_SERVICE',
        transport: Transport.RMQ,
        options: {
          urls: [process.env.RABBITMQ_URL!],
          queue: 'product_queue',
          queueOptions: {
            durable: false,
          },
        },
      },
    ]),
  ],
  controllers: [CartOrderController],
  providers: [CartOrderService, PrismaService],
})
export class CartOrderModule {}
