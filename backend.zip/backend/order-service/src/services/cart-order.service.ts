import { Inject, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { ClientProxy, RpcException } from '@nestjs/microservices';
import { firstValueFrom } from 'rxjs';
import { PrismaService } from 'src/prisma/prisma.service';

@Injectable()
export class CartOrderService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject('PRODUCT_SERVICE') private readonly productClient: ClientProxy,
  ) { }

  async addToCart(userId: string, productId: string, quantity: number) {
    const existing = await this.prisma.cartItem.findFirst({ where: { userId, productId } });

    if (existing) {
      await this.prisma.cartItem.update({
        where: { id: existing.id },
        data: { quantity: existing.quantity + quantity },
      });
    } else {
      await this.prisma.cartItem.create({ data: { userId, productId, quantity } });
    }

    return { message: 'Added to cart and stock updated.' };
  }

  async removeFromCart(userId: string, productId: string, quantity: number) {
    const item = await this.prisma.cartItem.findFirst({ where: { userId, productId } });
    if (!item || item.quantity < quantity) throw new Error('Not enough in cart.');

    if (item.quantity === quantity) {
      await this.prisma.cartItem.delete({ where: { id: item.id } });
    } else {
      await this.prisma.cartItem.update({
        where: { id: item.id },
        data: { quantity: item.quantity - quantity },
      });
    }

    return { message: 'Removed from cart and stock restored.' };
  }


async placeOrder(userId: string) {
  const cartItems = await this.prisma.cartItem.findMany({ where: { userId } });
  if (cartItems.length === 0) throw new Error('Cart is empty');

  const order = await this.prisma.order.create({
    data: {
      userId,
      items: {
        create: cartItems.map((item) => ({
          productId: item.productId,
          quantity: item.quantity,
        })),
      },
    },
  });

  // Emit stock decrease events for each item using firstValueFrom
  await Promise.all(
    cartItems.map((item) =>
      firstValueFrom(
        this.productClient.emit('product_stock_decrease', {
          productId: item.productId,
          quantity: item.quantity,
        })
      )
    )
  );

  // Clear the cart after order is placed
  await this.prisma.cartItem.deleteMany({ where: { userId } });

  return { message: 'Order placed successfully', orderId: order.id };
}

async getOrderHistory(userId: string) {
  const logger = new Logger('CartOrderService');

  try {
    const orders = await this.prisma.order.findMany({
      where: { userId },
      include: { items: true },
    });

    if (!orders.length) {
      throw new RpcException({
        statusCode: 404,
        error: 'Not Found',
        message: 'No orders found for this user',
      });
    }

    const enrichedOrders = await Promise.all(
      orders.map(async (order) => {
        const detailedItems = await Promise.all(
          order.items.map(async (item) => {
            try {
              const productDetails = await firstValueFrom(
                this.productClient.send('get_product_details', {
                  productId: item.productId,
                }),
              );
              return {
                ...item,
                productDetails,
              };
            } catch (err) {
              logger.error(
                `Product fetch error for productId ${item.productId}`,
                err,
              );
              return {
                ...item,
                productDetails: null,
              };
            }
          }),
        );

        return {
          ...order,
          orderItems: detailedItems,
        };
      }),
    );

    return enrichedOrders;
  } catch (error) {
    logger.error('Error in getOrderHistory:', error);

    // Ensure all errors passed to Gateway are RpcExceptions
    if (error instanceof RpcException) {
      throw error;
    }

    throw new RpcException({
      statusCode: 500,
      error: 'Internal Server Error',
      message: error?.message || 'Something went wrong',
    });
  }}
async getCartItems(userId: string) {
  const logger = new Logger('CartOrderService');

  try {
    const cartItems = await this.prisma.cartItem.findMany({
      where: { userId },
    });

    if (!cartItems.length) {
      throw new RpcException({
        statusCode: 404,
        error: 'Not Found',
        message: 'Cart is empty',
      });
    }

    const detailedItems = await Promise.all(
      cartItems.map(async (item) => {
        try {
          const productDetails = await firstValueFrom(
            this.productClient.send('get_product_details', {
              productId: item.productId,
            }),
          );

          return {
            ...item,
            productDetails,
          };
        } catch (err) {
          logger.error(`Error fetching product details for ${item.productId}`, err);
          return {
            ...item,
            productDetails: null,
          };
        }
      }),
    );

    return detailedItems;
  } catch (error) {
    logger.error('Error fetching cart items:', error);
    if (error instanceof RpcException) {
      throw error;
    }
    throw new RpcException({
      statusCode: 500,
      error: 'Internal Server Error',
      message: error?.message || 'Something went wrong',
    });
  }
}


}
