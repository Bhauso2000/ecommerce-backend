import { Module } from '@nestjs/common';
 
import { AdminController } from './controller/admin.controller';
import { AdminService } from './service/admin.service';
import { PrismaService } from 'src/common/prisma.service';

@Module({
  controllers: [AdminController],
  providers: [AdminService, PrismaService],
})
export class AdminModule {}
