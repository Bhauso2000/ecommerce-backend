import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsNumber, IsString, Min } from 'class-validator';

export class CreateProductDto {
  @ApiProperty({ example: 'Awesome Product' })
  @IsString()
  name: string;

  @ApiProperty({ example: 'This product is awesome' })
  @IsString()
  description: string;

  @ApiProperty({ example: 99.99 })
  @Transform(({ value }) => parseFloat(value)) // transform string to number
  @IsNumber()
  price: number;

  @ApiProperty({ example: 'http://image.url/product.jpg' })
  @IsString()
  imageUrl: string;

  @ApiProperty({ example: 100, description: 'Stock quantity' })
  @Transform(({ value }) => parseInt(value, 10)) // transform string to integer
  @IsNumber()
  @Min(0)
  stock: number;
}
