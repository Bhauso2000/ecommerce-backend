import { Injectable } from '@nestjs/common';
import { v2 as cloudinary, UploadApiResponse, UploadApiErrorResponse } from 'cloudinary';
import * as toStream from 'buffer-to-stream';

@Injectable()
export class CloudinaryService {
  constructor() {
    cloudinary.config({
      cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_API_SECRET,
    });
  }

async uploadImage(file: Express.Multer.File): Promise<UploadApiResponse> {
  return cloudinary.uploader.upload(file.path, {
    folder: 'products',
  });
}

async uploadBase64Image(base64: string): Promise<UploadApiResponse> {
  const base64Data = base64.replace(/^data:image\/\w+;base64,/, '');
  return cloudinary.uploader.upload(
    `data:image/jpeg;base64,${base64Data}`,
    {
      folder: 'products',
    },
  );
}

  async destroyImage(publicId: string): Promise<any> {
    return new Promise((resolve, reject) => {
      cloudinary.uploader.destroy(publicId, (error, result) => {
        if (error) return reject(error);
        resolve(result);
      });
    });
  }
}
