import {
  Controller,
  Post,
  Get,
  Patch,
  Delete,
  Param,
  Body,
  UploadedFile,
  UseInterceptors,
  Inject,
  Query,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ClientProxy } from '@nestjs/microservices';
import { Express } from 'express';
@Controller('products')
export class ProductController {
  constructor(@Inject('PRODUCT_SERVICE') private readonly productClient: ClientProxy) { }

@Post()
create(@Body() body:any) {
  // 'file' is a base64 string here
  return this.productClient.send('create_product', { file: body.file, dto: body});
}


  @Get()
  findAll() {
    return this.productClient.send('get_all_products', {});
  }

  @Get('getbyId/:id')
  findOne(@Param('id') id: string) {
    return this.productClient.send('get_product_by_id', { id });
  }

  @Patch(':id')
  @UseInterceptors(FileInterceptor('file'))
  update(@Param('id') id: string, @UploadedFile() file: Express.Multer.File, @Body() body: any) {
    return this.productClient.send('update_product', { id, ...body, file });
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.productClient.send('delete_product', { id });
  }
  @Get('search')
  searchProducts(
    @Query('page') page = 1,
    @Query('limit') limit = 10,
    @Query('search') search = '',
    @Query('order') order = 'asc',
  ) {
    return this.productClient.send('search_products', {
      page: +page,
      limit: +limit,
      search,
      order
    });
  }


}
