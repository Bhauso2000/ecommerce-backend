import { Body, Controller, Get, Post, Request } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { Inject } from '@nestjs/common';
import { firstValueFrom } from 'rxjs';

@Controller('customer')
export class CustomerController {
  constructor(
    @Inject('CUSTOMER_SERVICE') private readonly customerClient: ClientProxy,
  ) {}

  @Post('signup')
  async signup(@Body() dto: any) {
    return firstValueFrom(this.customerClient.send('create_customer', dto));
  }

  @Post('login')
  async login(@Body() dto: any) {
    return firstValueFrom(
      this.customerClient.send('login_customer', { email: dto.email, password: dto.password }),
    );
  }

  @Get('authuser')
  async getProfile(@Request() req) {
    return firstValueFrom(this.customerClient.send('get_auth_user', req.user.sub));
  }
}
