import { Controller, Get, UseGuards } from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { Roles } from 'src/common/decorators/roles.decorator';
import { RolesGuard } from './guards/roles.guard';

 
@Controller('admin')
@UseGuards(RolesGuard)
export class AdminController {
  constructor(
    @Inject('CUSTOMER_SERVICE') private readonly adminClient: ClientProxy,
  ) {}

  @Get('customers')
  @Roles('admin') // Only admin can access
  async getAllCustomers() {
    // Send a message to microservice and await the response
    return this.adminClient.send('get_all_customers', {}).toPromise();
  }
}
