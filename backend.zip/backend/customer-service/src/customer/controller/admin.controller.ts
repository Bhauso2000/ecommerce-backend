import { MessagePattern } from '@nestjs/microservices';
import { AdminService } from '../service/admin.service';
import { Controller } from '@nestjs/common';
@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @MessagePattern('get_all_customers')
  async getAllCustomers() {
    return this.adminService.getAllCustomers();
  }
}
