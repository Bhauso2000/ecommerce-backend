import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Request,
  Inject,
} from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { lastValueFrom } from 'rxjs';

@Controller('addresses')
export class AddressController {
  constructor(
    @Inject('CUSTOMER_SERVICE') private readonly addressClient: ClientProxy,
  ) {}

  @Post()
  async create(@Body() dto: any, @Request() req: any): Promise<any> {
    const payload = { ...dto, customerId: req.user.sub };
    return lastValueFrom(this.addressClient.send('create_address', payload));
  }

  @Get('customer')
  async getByCustomer(@Request() req: any): Promise<any> {
    return lastValueFrom(
      this.addressClient.send('get_addresses_by_customer', req.user.sub),
    );
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() dto: any): Promise<any> {
    return lastValueFrom(
      this.addressClient.send('update_address', { id, ...dto }),
    );
  }

  @Delete(':id')
  async delete(@Param('id') id: string): Promise<any> {
    return lastValueFrom(this.addressClient.send('delete_address', id));
  }
}
