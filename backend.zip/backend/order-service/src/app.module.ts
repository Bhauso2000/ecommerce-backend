import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { CartOrderModule } from './cart-order.module';

@Module({
  imports: [],
  controllers: [AppController,CartOrderModule],
  providers: [AppService],
})
export class AppModule {}
