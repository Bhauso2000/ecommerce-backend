import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "src/common/prisma.service";
import { CreateAddressDto, UpdateAddressDto } from "../dto/address.dto";

@Injectable()
export class AddressService{
    constructor(private prisma:PrismaService){}
    async create(data:CreateAddressDto){
        return this.prisma.address.create({data})
    }
    async findByCustomer(customerId:string){
        return this.prisma.address.findMany({where:{customerId}})
    }
    async update(id:string,data:UpdateAddressDto){
        const address=await this.prisma.address.findUnique({where:{id}})
        if(!address) throw new NotFoundException('Address not found')
            return this.prisma.address.update({where:{id},data})
    }
    async delete(id:string){
        return this.prisma.address.delete({where:{id}})
    }
}