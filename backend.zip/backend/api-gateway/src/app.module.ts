import { Module, NestModule, MiddlewareConsumer, RequestMethod } from '@nestjs/common';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { ProductController } from './product.controller';
import { JwtModule } from '@nestjs/jwt';
import { JwtMiddleware } from './common/jwt.middleware';
import { AuthModule } from './auth/auth.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { CustomerController } from './customer.controller';
import { AdminController } from './admin.controller';
import { AddressController } from './address.controller';
import { CartOrderController } from './cart-ordercontroller';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ClientsModule.register([
      {
        name: 'PRODUCT_SERVICE',
        transport: Transport.RMQ,
        options: {
          urls: [process.env.RABBITMQ_URL || 'amqp://localhost:5672'],
          queue: 'product_queue',
          queueOptions: { durable: false },
        },
      },
      {
        name: 'CUSTOMER_SERVICE',
        transport: Transport.RMQ,
        options: {
          urls: [process.env.RABBITMQ_URL || 'amqp://localhost:5672'],
          queue: 'customer_queue',
          queueOptions: { durable: false },
        },
      },
       {
        name: 'CART_ORDER_SERVICE',
        transport: Transport.RMQ,
        options: {
          urls: [process.env.RABBITMQ_URL || 'amqp://localhost:5672'],
          queue: 'cart_order_queue',  // make sure this matches microservice queue name
          queueOptions: {
            durable: true,
          },
        },
      },
    ]),
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (config: ConfigService) => ({
        secret: config.get<string>('JWT_SECRET'),
        signOptions: { expiresIn: config.get<string | number>('JWT_EXPIRES_IN') },
      }),
    }),
    AuthModule,
  ],
  controllers: [ProductController,CustomerController,AdminController,AddressController,CartOrderController],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(JwtMiddleware)
      .exclude(
        { path: 'customer/signup', method: RequestMethod.POST },
        { path: 'customer/login', method: RequestMethod.POST },
        { path: 'products/*', method: RequestMethod.GET },

        { path: 'api', method: RequestMethod.GET },
        { path: 'api-json', method: RequestMethod.GET },
        { path: '', method: RequestMethod.GET },
      )
      .forRoutes({ path: '*', method: RequestMethod.ALL });
  }
}
