import { IsString, IsUUID } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateAddressDto {
  @ApiProperty({ example: '123 Main St', description: 'Street name of the address' })
  @IsString()
  street: string;

  @ApiProperty({ example: 'New York', description: 'City of the address' })
  @IsString()
  city: string;

  @ApiProperty({ example: 'NY', description: 'State of the address' })
  @IsString()
  state: string;

  @ApiProperty({ example: '10001', description: 'Postal code' })
  @IsString()
  postalCode: string;

  @ApiProperty({ example: 'USA', description: 'Country of the address' })
  @IsString()
  country: string;

  @ApiProperty({ format: 'uuid', example: 'a4d68c38-9f8e-4adf-8326-cdab57e234d2', description: 'UUID of the customer' })
  @IsUUID()
  customerId: string;
}

export class UpdateAddressDto {
  @ApiPropertyOptional({ example: '123 Main St', description: 'Street name of the address' })
  @IsString()
  street?: string;

  @ApiPropertyOptional({ example: 'New York', description: 'City of the address' })
  @IsString()
  city?: string;

  @ApiPropertyOptional({ example: 'NY', description: 'State of the address' })
  @IsString()
  state?: string;

  @ApiPropertyOptional({ example: '10001', description: 'Postal code' })
  @IsString()
  postalCode?: string;

  @ApiPropertyOptional({ example: 'USA', description: 'Country of the address' })
  @IsString()
  country?: string;
}
