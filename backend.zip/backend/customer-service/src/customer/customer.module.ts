import { Module } from "@nestjs/common";
import { AuthModule } from "../auth/auth.module";
import { CustomerSevice } from "./service/customer.service";
import { PrismaService } from "../common/prisma.service";
import { CustomerController } from "./controller/customer.controller";

@Module({
    imports:[AuthModule],
    controllers:[CustomerController],
    providers:[CustomerSevice,PrismaService],
})
export class CustomerModule {}
