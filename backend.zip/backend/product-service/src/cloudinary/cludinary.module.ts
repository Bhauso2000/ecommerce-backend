import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { CloudinaryService } from './cloudinary.service'; // 👈 Ensure this is imported
import { CloudinaryProvider } from './cloudinary.provider'; // If you're using a separate provider

@Module({
  imports: [ConfigModule],
  providers: [CloudinaryProvider, CloudinaryService], // 👈 Add CloudinaryService here
  exports: [CloudinaryService], // 👈 Export CloudinaryService
})
export class CloudinaryModule {}
