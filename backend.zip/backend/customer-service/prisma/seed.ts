// prisma/seed.ts
import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash('password123', 10);

  // Create admin
  await prisma.customer.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      name: 'Admin User',
      email: 'admin@example.com',
      password: hashedPassword,
      role: 'admin',
      address: {
        create: [
          {
            street: '123 Admin Street',
            city: 'Adminville',
            state: 'Adminstate',
            postalCode: '000001',
            country: 'Adminland',
          },
        ],
      },
    },
  });

  // Create regular user
  await prisma.customer.upsert({
    where: { email: 'user@example.com' },
    update: {},
    create: {
      name: 'Normal User',
      email: 'user@example.com',
      password: hashedPassword,
      role: 'user',
      address: {
        create: [
          {
            street: '456 User Road',
            city: 'Usercity',
            state: 'Userstate',
            postalCode: '000002',
            country: 'Userland',
          },
        ],
      },
    },
  });

  console.log('✅ Seeding complete.');
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
