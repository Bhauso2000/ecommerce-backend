// prisma/seed.ts
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const productsData = Array.from({ length: 10 }).map((_, i) => ({
    name: `Sample Product ${i + 1}`,
    description: `This is sample product number ${i + 1} seeded into the database.`,
    price: 29.99 + i, // Just vary the price a bit
    stock: 100 - i * 5,
    imageUrl: `https://next-ecommerce-shopco.vercel.app/_next/image?url=%2Fimages%2Fpic${(i % 5) + 1}.png&w=640&q=75`,
  }));

  for (const product of productsData) {
    await prisma.product.create({
      data: product,
    });
  }

  console.log('10 Products seeded successfully.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
