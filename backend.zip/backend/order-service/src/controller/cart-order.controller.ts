import { Controller, NotFoundException, InternalServerErrorException, Logger } from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { AddToCartDto } from 'src/dto/add-to-cart.dto';
import { RemoveFromCartDto } from 'src/dto/romove-from-cart.dto';
import { CartOrderService } from 'src/services/cart-order.service';

const logger = new Logger('CartOrderMicroservice');

 

@Controller('cart-order')
export class CartOrderController {
  constructor(private readonly service: CartOrderService) {}

  @MessagePattern('add_to_cart')
  async add(data: { userId: string; productId: string; quantity: number }) {
    try {
      return await this.service.addToCart(data.userId, data.productId, data.quantity);
    } catch (error) {
      logger.error('Add to cart error:', error);
      throw error;
    }
  }

  @MessagePattern('remove_from_cart')
  async remove(data: { userId: string; productId: string; quantity: number }) {
    try {
      return await this.service.removeFromCart(data.userId, data.productId, data.quantity);
    } catch (error) {
      logger.error('Remove from cart error:', error);
      throw error;
    }
  }

  @MessagePattern('place_order')
  async placeOrder(data: { userId: string }) {
    try {
      return await this.service.placeOrder(data.userId);
    } catch (error) {
      logger.error('Place order error:', error);
      throw error;
    }
  }
      @MessagePattern('get_order_history')
      async getOrderHistory(data: { userId: string }) {
        try {
          return await this.service.getOrderHistory(data.userId);
        } catch (error) {
          throw error;
        }
      }
 @MessagePattern('get_cart_items')
  async getCartItems(@Payload() data: { userId: string }) {
    try {
      return await this.service.getCartItems(data.userId);
    } catch (error) {
      logger.error('Get cart items error:', error);
      throw new InternalServerErrorException('Failed to retrieve cart items');
    }
  }
}
