import { NestFactory } from '@nestjs/core';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import { CartOrderModule } from './cart-order.module';

async function bootstrap() {
  const app = await NestFactory.createMicroservice<MicroserviceOptions>(CartOrderModule, {
    transport: Transport.RMQ,
    options: {
      urls: [process.env.RABBITMQ_URL || 'amqp://localhost:5672'],
      queue: 'cart_order_queue',   // <== your cart order microservice queue
      queueOptions: {
        durable: true,
      },
    },
  });

  await app.listen();
  console.log('CartOrder microservice is listening on cart_order_queue...');
}
bootstrap();
