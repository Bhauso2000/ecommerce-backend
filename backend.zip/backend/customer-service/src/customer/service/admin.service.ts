// src/admin/admin.service.ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma.service';

@Injectable()
export class AdminService {
  constructor(private prisma: PrismaService) {}

  async getAllCustomers() {
    const customers = await this.prisma.customer.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        created: true,
        address: true,
      },
    });
    return customers;
  }
}
