import { Controller } from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { AddressService } from '../service/address.service';
import { CreateAddressDto, UpdateAddressDto } from '../dto/address.dto';

@Controller()
export class AddressController {
  constructor(private readonly service: AddressService) {}

  @MessagePattern('create_address')
  create(@Payload() data: CreateAddressDto & { customerId: string }) {
    return this.service.create(data);
  }

  @MessagePattern('get_addresses_by_customer')
  getByCustomer(@Payload() customerId: string) {
    return this.service.findByCustomer(customerId);
  }

  @MessagePattern('update_address')
  update(@Payload() payload: { id: string } & UpdateAddressDto) {
    const { id, ...dto } = payload;
    return this.service.update(id, dto);
  }

  @MessagePattern('delete_address')
  delete(@Payload() id: string) {
    return this.service.delete(id);
  }
}
