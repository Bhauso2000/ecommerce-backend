import { Module } from "@nestjs/common";
import { AuthModule } from "../auth/auth.module";
import { PrismaService } from "../common/prisma.service";
import { AddressController } from "./controller/address.controller";
import { AddressService } from "./service/address.service";

@Module({
    imports:[AuthModule],
    controllers:[AddressController],
    providers:[AddressService,PrismaService],
})
export class AddressModule {}
