import { Body, Controller, Get, NotFoundException, Param, Post, Query, Req } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { Inject } from '@nestjs/common';
import { firstValueFrom, lastValueFrom } from 'rxjs';


interface AuthenticatedRequest {
  user: { sub: string;[key: string]: any };
}

@Controller('cart-order')
export class CartOrderController {
  constructor(
    @Inject('CART_ORDER_SERVICE') private readonly productClient: ClientProxy,
  ) { }

  @Post('add')
  async add(@Req() req: AuthenticatedRequest, @Body() dto: any) {
    const userId = req.user.sub;
    return firstValueFrom(
      this.productClient.send('add_to_cart', { userId, productId: dto.productId, quantity: dto.quantity }),
    );
  }
 @Get('history')
  async getOrderHistory(@Query('userId') userId: string) {
    const orders = await firstValueFrom(
      this.productClient.send('get_order_history', { userId }),
    );
    return orders;
  }
  @Post('remove')
  async remove(@Req() req: AuthenticatedRequest, @Body() dto: any) {
    const userId = req.user.sub;
    return firstValueFrom(
      this.productClient.send('remove_from_cart', { userId, productId: dto.productId, quantity: dto.quantity }),
    );
  }

  @Post('order')
  async placeOrder(@Req() req: AuthenticatedRequest) {
    const userId = req.user.sub;
    return firstValueFrom(
      this.productClient.send('place_order', { userId }),
    );
  }
     @Get('items')
  async getCartItems(@Req() req: AuthenticatedRequest) {
    const userId = req.user.sub;
    return firstValueFrom(
      this.productClient.send('get_cart_items', { userId }),
    );
  }
}
