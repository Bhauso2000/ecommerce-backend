import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { CustomerModule } from './customer/customer.module';
import { AddressModule } from './customer/address.module';
import { AdminModule } from './customer/admin.module';


@Module({
  imports: [
AdminModule,
    CustomerModule, AddressModule
  ],
  controllers: [AppController],
  providers: [AppService],
})

  
export class AppModule  {
  
}