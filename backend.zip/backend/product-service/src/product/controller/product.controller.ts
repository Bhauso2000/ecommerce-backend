import {
  Controller,
  Post,
  Get,
  Put,
  Delete,
  Param,
  Body,
  UploadedFile,
  UseInterceptors,
  Patch,
  NotFoundException,
  InternalServerErrorException,
  Logger,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiConsumes, ApiBody } from '@nestjs/swagger';
import { ProductService } from '../service/product.service';
import { CreateProductDto } from '../dto/create-product.dto';
import { UpdateProductDto } from '../dto/update-product-dto';
import { MessagePattern } from '@nestjs/microservices';
const logger = new Logger('ProductMicroservice');
@ApiTags('products')
@Controller('products')
export class ProductController {
  constructor(private readonly productService: ProductService) { }

  @Post()
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { type: 'string', format: 'binary' },
        name: { type: 'string', example: 'Awesome Product' },
        description: { type: 'string', example: 'This product is awesome' },
        price: { type: 'number', example: 99.99 },
        stock: { type: 'integer', example: 100 },
      },
      required: ['name', 'price', 'stock'],
    },
  })
  @UseInterceptors(FileInterceptor('file'))
  create(
    @UploadedFile() file: Express.Multer.File,
    @Body() dto: CreateProductDto,
  ) {
    return this.productService.create(file, dto);
  }

@MessagePattern('create_product')
async createMicroservice(data: { file: Express.Multer.File; dto: CreateProductDto }) {
  try {
    return await this.productService.create(data?.file, data.dto);
  } catch (error) {
    console.error('Error creating product:', error);
    throw error;
  }
}

  @Get()
  findAll() {
    return this.productService.findAll();
  }

  @MessagePattern('get_all_products')
  findAllMicroservice() {
    return this.productService.findAll();
  }

  @Get('getbyId/:id')
  findOneHttp(@Param('id') id: string) {
    return this.productService.findOne(id);
  }

  @MessagePattern('get_product_by_id')
  findOneMicroservice(data: { id: string }) {
    return this.productService.findOne(data.id);
  }

  @Patch(':id')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { type: 'string', format: 'binary' },
        name: { type: 'string', example: 'Updated Product Name' },
        description: { type: 'string', example: 'Updated product description' },
        price: { type: 'number', example: 49.99 },
        stock: { type: 'integer', example: 50 },
        imageUrl: { type: 'string', example: 'http://image.url/updated.jpg' },
      },
      required: [],
    },
  })
  @UseInterceptors(FileInterceptor('file'))
  update(
    @Param('id') id: string,
    @UploadedFile() file: Express.Multer.File,
    @Body() dto: UpdateProductDto,
  ) {
    return this.productService.update(id, file, dto);
  }

  @MessagePattern('update_product')
  updateMicroservice(data: { id: string; file: Express.Multer.File, dto: UpdateProductDto }) {
    return this.productService.update(data.id, data.file, data.dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.productService.remove(id);
  }

  @MessagePattern('delete_product')
  async removeMicroservice(data: { id: string }) {
    console.error('Microservice delete error:',);

    try {
      return await this.productService.remove(data.id);
    } catch (error) {
      console.error('Microservice delete error:', error);

      if (error instanceof NotFoundException) {
        throw error;
      }

      throw new InternalServerErrorException('Product deletion failed');
    }
  }
  @MessagePattern('get_product_details')
  async getProductDetails(data: { productId: string }) {
    // Fetch product details from DB or wherever
    const product = await this.productService.findOne(data.productId);
    if (!product) {
      throw new NotFoundException('Product not found');
    }
    return product;
  }
 @MessagePattern('product_stock_decrease')
  async handleStockDecrease(data: { productId: string; quantity: number }) {
    try {
      return await this.productService.decreaseStock(data.productId, data.quantity);
    } catch (error) {
      throw error;
    }
  }

  @MessagePattern('product_stock_increase')
  async handleStockIncrease(data: { productId: string; quantity: number }) {
    try {
      return await this.productService.increaseStock(data.productId, data.quantity);
    } catch (error) {
      throw error;
    }
  }
  @MessagePattern('search_products')
async searchProducts(data: { page: number; limit: number; search?: string;order:'asc' | 'desc'   }) {
  const { page, limit, search,order } = data;
  return this.productService.searchProducts(page, limit, search,order);
}


}
